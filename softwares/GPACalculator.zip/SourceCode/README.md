# GPACalculator

Terminal based GPA Calculator application. 
GPA points based on NC State University's.

 OS | Instruction
--- | ---
Windows | Run gpa.exe
UNIX | Issue "make" command to compile and issue "./gpa" to run.
